import streamlit as st
import pymysql 
import pandas as pd

mydb= pymysql.connect(
    host="localhost",
    user="root",
    password="praveenK98@",
    database="registerformDB"
)

mydb.autocommit(True)

cursor=mydb.cursor()
st.image("C:/Users/user/Downloads/cricketimage.jpg", width=400)

st.title("Registration Form")
with st.form(key='registration_form'):
    name = st.text_input("Name")
    email = st.text_input("Email")
    password = st.text_input("Password", type="password")
    v1 = st.radio("Cricket", ['Batsman', 'Bowler', 'Allrounder'])
    dob = st.date_input("Date of Birth")
    mobile_Number = st.text_input("Mobile_number")
    gender = st.radio("Gender", ("Male", "Female", "Other"))
    country = st.selectbox("Country", ["India", "United States", "Canada", "United Kingdom", "Australia", "Other"])

    # Submit button
    submit_button = st.form_submit_button(label='Register')

if submit_button:
    if dob.day != 0:

     form_data={
        'Name':name,
        'Email':email,
        'v1':v1,
        'dob':dob,
        'Mobile_Number':mobile_Number,
        'Gender':gender,
        'Country':country


    }

    df=pd.DataFrame([form_data])
    
    st.success("Registration Successful!!!")


    st.write("Here are your details:")

    st.table(df)

    insert_query="""
    INSERT INTO registrations(name,email,v1,dob,Mobile_Number,Gender,Country)
    VALUES (%s,%s,%s,%s,%s,%s,%s)
    """

    data=(name,email,v1, dob.strftime('%Y-%m-%d'),mobile_Number,gender,country)
    
    cursor.execute(insert_query,data)

    st.success("Data inserted successfully ")
